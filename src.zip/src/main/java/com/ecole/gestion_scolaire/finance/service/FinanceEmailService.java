package com.ecole.gestion_scolaire.finance.service;

import com.ecole.gestion_scolaire.finance.entity.FinanceEmailOutbox;
import com.ecole.gestion_scolaire.finance.repository.FinanceEmailOutboxRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.OffsetDateTime;
import java.util.Locale;

@Service
public class FinanceEmailService {
    private final FinanceEmailOutboxRepository outbox;
    private final PaymentReceiptService receipts;
    private final ApplicationContext context;

    @Value("${app.finance-email.enabled:true}")
    private boolean enabled;
    @Value("${app.finance-email.from:}")
    private String from;

    public FinanceEmailService(FinanceEmailOutboxRepository outbox, PaymentReceiptService receipts, ApplicationContext context) {
        this.outbox = outbox;
        this.receipts = receipts;
        this.context = context;
    }

    public void queuePaymentReceipt(Long paymentId) {
        var receipt = receipts.get(paymentId);
        if (receipt.guardianEmail() == null || receipt.guardianEmail().isBlank()) return;
        var x = new FinanceEmailOutbox();
        x.setRecipientEmail(receipt.guardianEmail().trim());
        x.setSubject("Reçu de paiement " + receipt.paymentNumber());
        x.setDocumentType("PAYMENT_RECEIPT");
        x.setDocumentId(paymentId);
        x.setBodyHtml(paymentHtml(receipt));
        x = outbox.save(x);
        scheduleDelivery(x.getId());
    }

    public void queueRefundReceipt(Long refundId, Long paymentId, BigDecimal refundedAmount,
                                   BigDecimal creditReversed, BigDecimal allocationReversed) {
        var receipt = receipts.get(paymentId);
        if (receipt.guardianEmail() == null || receipt.guardianEmail().isBlank()) return;
        var x = new FinanceEmailOutbox();
        x.setRecipientEmail(receipt.guardianEmail().trim());
        x.setSubject("Confirmation de remboursement - " + receipt.paymentNumber());
        x.setDocumentType("REFUND_RECEIPT");
        x.setDocumentId(refundId);
        x.setBodyHtml(refundHtml(receipt, refundedAmount, creditReversed, allocationReversed));
        x = outbox.save(x);
        scheduleDelivery(x.getId());
    }

    public int retryPending() {
        int sent = 0;
        for (var x : outbox.findTop50ByStatusOrderByCreatedAtAsc("PENDING")) if (tryDeliver(x.getId())) sent++;
        return sent;
    }

    private void scheduleDelivery(Long id) {
        if (!enabled) return;
        if (TransactionSynchronizationManager.isActualTransactionActive()) {
            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                @Override public void afterCommit() { tryDeliver(id); }
            });
        } else tryDeliver(id);
    }

    public boolean tryDeliver(Long id) {
        if (!enabled) return false;
        var x = outbox.findById(id).orElse(null);
        if (x == null || "SENT".equals(x.getStatus())) return false;
        try {
            Class<?> senderClass = Class.forName("org.springframework.mail.javamail.JavaMailSender");
            Object sender = context.getBean(senderClass);
            Object mimeMessage = senderClass.getMethod("createMimeMessage").invoke(sender);
            Class<?> mimeMessageClass = Class.forName("jakarta.mail.internet.MimeMessage");
            Class<?> helperClass = Class.forName("org.springframework.mail.javamail.MimeMessageHelper");
            Object helper = helperClass.getConstructor(mimeMessageClass, boolean.class, String.class)
                    .newInstance(mimeMessage, true, "UTF-8");
            helperClass.getMethod("setTo", String.class).invoke(helper, x.getRecipientEmail());
            helperClass.getMethod("setSubject", String.class).invoke(helper, x.getSubject());
            helperClass.getMethod("setText", String.class, boolean.class).invoke(helper, x.getBodyHtml(), true);
            if (from != null && !from.isBlank()) helperClass.getMethod("setFrom", String.class).invoke(helper, from.trim());
            senderClass.getMethod("send", mimeMessageClass).invoke(sender, mimeMessage);
            x.setStatus("SENT");
            x.setSentAt(OffsetDateTime.now());
            x.setLastError(null);
            x.setAttemptCount(x.getAttemptCount() + 1);
            outbox.save(x);
            return true;
        } catch (Exception ex) {
            x.setStatus("PENDING");
            x.setAttemptCount(x.getAttemptCount() + 1);
            String msg = ex.getMessage();
            if (msg == null && ex.getCause() != null) msg = ex.getCause().getMessage();
            x.setLastError(msg == null ? ex.getClass().getSimpleName() : msg.substring(0, Math.min(1800, msg.length())));
            outbox.save(x);
            return false;
        }
    }

    private String paymentHtml(com.ecole.gestion_scolaire.finance.dto.receipt.PaymentReceiptResponse r) {
        StringBuilder rows = new StringBuilder();
        for (var line : r.allocations()) {
            rows.append("<tr><td>").append(esc((line.studentFirstName()==null?"":line.studentFirstName()+" ")+(line.studentLastName()==null?"":line.studentLastName())))
                    .append("</td><td>").append(esc(line.chargeLabel())).append("</td><td style='text-align:right'>")
                    .append(money(line.amount())).append("</td></tr>");
        }
        return shell("Reçu de paiement", """
                <h2>Reçu de paiement</h2>
                <p><strong>Référence :</strong> %s<br><strong>Responsable :</strong> %s %s</p>
                <table><thead><tr><th>Élève</th><th>Créance</th><th>Montant affecté</th></tr></thead><tbody>%s</tbody></table>
                <div class='totals'>
                  <p>Total des frais réglés : <strong>%s</strong></p>
                  <p>Montant reçu : <strong>%s</strong></p>
                  <p>Versé dans l'avoir familial : <strong>%s</strong></p>
                  <p>Solde actuel de l'avoir issu de ce paiement : <strong>%s</strong></p>
                </div>
                <p class='note'>Le montant reçu peut être supérieur au total des créances réglées. Le reliquat est conservé dans l'avoir familial.</p>
                """.formatted(esc(r.paymentNumber()), esc(r.guardianFirstName()), esc(r.guardianLastName()), rows,
                money(r.allocatedAmount()), money(r.totalAmount()), money(r.creditCreatedAmount()), money(r.creditRemainingAmount())));
    }

    private String refundHtml(com.ecole.gestion_scolaire.finance.dto.receipt.PaymentReceiptResponse r,
                              BigDecimal amount, BigDecimal creditReversed, BigDecimal allocationReversed) {
        return shell("Confirmation de remboursement", """
                <h2>Confirmation de remboursement</h2>
                <p><strong>Paiement d'origine :</strong> %s<br><strong>Responsable :</strong> %s %s</p>
                <div class='totals'>
                  <p>Montant remboursé : <strong>%s</strong></p>
                  <p>Prélevé sur l'avoir familial : <strong>%s</strong></p>
                  <p>Montant ayant réouvert des créances : <strong>%s</strong></p>
                  <p>Total remboursé sur ce paiement : <strong>%s</strong></p>
                  <p>Net encaissé restant : <strong>%s</strong></p>
                  <p>Solde actuel de l'avoir issu de ce paiement : <strong>%s</strong></p>
                </div>
                <p class='note'>La partie du remboursement qui correspondait à des créances déjà réglées les réouvre automatiquement, partiellement ou totalement.</p>
                """.formatted(esc(r.paymentNumber()),esc(r.guardianFirstName()),esc(r.guardianLastName()),money(amount),
                money(creditReversed),money(allocationReversed),money(r.refundedAmount()),money(r.netReceivedAmount()),money(r.creditRemainingAmount())));
    }

    private String shell(String title, String body) {
        return """
            <!doctype html><html><head><meta charset='UTF-8'><style>
            body{font-family:Arial,sans-serif;color:#172033;max-width:760px;margin:auto;padding:24px}h2{color:#0f2742}
            table{width:100%%;border-collapse:collapse;margin:20px 0}th,td{padding:10px;border-bottom:1px solid #ddd;text-align:left}
            .totals{background:#f5f7fb;padding:14px 18px;border-radius:10px}.note{font-size:13px;color:#667085}
            </style><title>%s</title></head><body>%s</body></html>
            """.formatted(esc(title), body);
    }

    private String money(BigDecimal v){ if(v==null)v=BigDecimal.ZERO; NumberFormat f=NumberFormat.getNumberInstance(Locale.FRANCE); f.setMinimumFractionDigits(2); f.setMaximumFractionDigits(2); return f.format(v)+" DA"; }
    private String esc(String s){ if(s==null)return ""; return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;"); }
}
