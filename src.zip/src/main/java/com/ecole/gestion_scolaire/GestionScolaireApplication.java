package com.ecole.gestion_scolaire;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class GestionScolaireApplication {

    public static void main(String[] args) {
        SpringApplication.run(GestionScolaireApplication.class, args);
    }

}
