package com.ecole.gestion_scolaire.finance.controller;

import com.ecole.gestion_scolaire.common.dto.PageResponse;
import com.ecole.gestion_scolaire.finance.dto.credit.*;
import com.ecole.gestion_scolaire.finance.service.FamilyCreditService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/finance/family-credits")
public class FamilyCreditController {
    private final FamilyCreditService s;

    public FamilyCreditController(FamilyCreditService x) {
        s = x;
    }

    @GetMapping
    @PreAuthorize("hasAuthority('PAIEMENT_CONSULTER')")
    public PageResponse<FamilyCreditResponse> all(@RequestParam Long guardianId, @RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "20") int size) {
        return s.byGuardian(guardianId, page, size);
    }
}
