package com.ecole.gestion_scolaire.finance.service;

import com.ecole.gestion_scolaire.common.dto.PageResponse;
import com.ecole.gestion_scolaire.finance.dto.credit.*;
import com.ecole.gestion_scolaire.finance.entity.FamilyCredit;
import com.ecole.gestion_scolaire.finance.repository.FamilyCreditRepository;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

@Service
public class FamilyCreditService {
    private final FamilyCreditRepository repo;

    public FamilyCreditService(FamilyCreditRepository r) {
        repo = r;
    }

    @Transactional
    public FamilyCreditResponse create(Long guardianId, Long paymentId, BigDecimal amount) {
        if (amount.signum() <= 0) return null;
        var x = new FamilyCredit();
        x.setGuardianId(guardianId);
        x.setSourcePaymentId(paymentId);
        x.setInitialAmount(amount);
        x.setRemainingAmount(amount);
        x.setStatus("AVAILABLE");
        return toResponse(repo.save(x));
    }

    @Transactional(readOnly = true)
    public PageResponse<FamilyCreditResponse> byGuardian(Long id, int page, int size) {
        var p = PageRequest.of(Math.max(0, page), Math.min(100, Math.max(1, size)), Sort.by("createdAt").descending());
        return PageResponse.from(repo.findByGuardianId(id, p).map(this::toResponse));
    }

    public FamilyCreditResponse toResponse(FamilyCredit x) {
        return new FamilyCreditResponse(x.getId(), x.getGuardianId(), x.getSourcePaymentId(), x.getInitialAmount(), x.getRemainingAmount(), x.getStatus(), x.getCreatedAt());
    }
}
